package es.iespuertodelacruz.jmcg.recetasapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecetasApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
