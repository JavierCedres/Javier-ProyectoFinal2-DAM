package es.iespuertodelacruz.jmcg.recetasapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecetasApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecetasApiApplication.class, args);
	}

}
